from .....services import LogService
from .....services import LocationService
from .....services import MaterialService
from .....services import ObjectService
from .....services import AnimationService
from .....services import RigService
from ..... import ClassManager
from ....mpfboperator import MpfbOperator
from ....mpfbcontext import MpfbContext
from ....pollstrategy import pollstrategy, PollStrategy
import bpy, json, math, os
from bpy.types import StringProperty
from bpy_extras.io_utils import ExportHelper

_LOG = LogService.get_logger("animops.repeatanim")

@pollstrategy(PollStrategy.ANY_ARMATURE_OBJECT_ACTIVE)
class MPFB_OT_Repeat_Animation_Operator(MpfbOperator):
    """WARNING: THIS IS RATHER EXPERIMENTAL. Repeat an animation by copying its keyframes, optionally with given offsets and distance shifts. Note that if all you want is to make an animation cyclic, this is probably overkill"""
    bl_idname = "mpfb.repeat_animation"
    bl_label = "Repeat animation"
    bl_options = {'REGISTER', 'UNDO'}

    def get_logger(self):
        return _LOG

    def hardened_execute(self, context):
        _LOG.enter()

        armature_object = context.active_object

        from ...animops.animopspanel import ANIMOPS_PROPERTIES  # pylint: disable=C0415

        ctx = MpfbContext(context=context, scene_properties=ANIMOPS_PROPERTIES)

        skip = 0
        if ctx.skipfirst:
            skip = 1

        if not ctx.iterations:
            self.report({'ERROR'}, "Must specify a positive number of iterations")
            return {'CANCELLED'}

        bpy.ops.object.mode_set(mode='POSE', toggle=False)

        max_keyframe = AnimationService.get_max_keyframe(armature_object)
        _LOG.debug("max_keyframe", max_keyframe)

        total_distance = AnimationService.get_bone_movement_distance(armature_object, "mixamorig:Hips", skip, max_keyframe)
        first_distance = AnimationService.get_bone_movement_distance(armature_object, "mixamorig:Hips", skip, skip+1)
        _LOG.debug("total_distance", total_distance)
        _LOG.debug("first_distance", first_distance)
        distance = total_distance

        for i in range(ctx.iterations):
            first_keyframe = max_keyframe + ctx.offset + (i*(max_keyframe-skip))
            last_keyframe = first_keyframe + max_keyframe - skip
            _LOG.debug("first, last, skip", (first_keyframe, last_keyframe, skip))
            AnimationService.duplicate_keyframes(armature_object, first_keyframe, skip, max_keyframe)

            currdist = [distance[0] * (i+1), distance[1] * (i+1), distance[2] * (i+1)]
            AnimationService.move_bone_for_all_keyframes(armature_object, "mixamorig:Hips", currdist, first_keyframe, last_keyframe)

        bpy.ops.object.mode_set(mode='OBJECT', toggle=False)

        self.report({'INFO'}, "Done")
        return {'FINISHED'}

ClassManager.add_class(MPFB_OT_Repeat_Animation_Operator)
